// server.js
const express = require('express');
const dotenv = require('dotenv');
const path = require('path');
const session = require('express-session');
const bodyParser = require('body-parser');
const db = require('./models/db');
const authRoutes = require('./routes/authroutes');
const userRoutes = require('./routes/userRoutes');

dotenv.config();
const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Session
app.use(session({
  secret: 'votre_secret_key',
  resave: false,
  saveUninitialized: false
}));

// Routes auth & API
app.use('/', authRoutes);
app.use('/api', userRoutes);

// Routes CRUD Étudiants
app.get('/', (req, res) => {
  db.query('SELECT * FROM etudiants', (err, etudiants) => {
    if (err) return res.status(500).send(err);
    res.render('index', { etudiants });
  });
});

app.get('/ajouter', (req, res) => {
  res.render('add');
});

app.post('/ajouter', (req, res) => {
  const { mat, nom, prenom, datenaiss, classe, filiere, universite, adresse, sexe, nationalite } = req.body;
  const sql = 'INSERT INTO etudiants (mat, nom, prenom, datenaiss, classe, filiere, universite, adresse, sexe, nationalite) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
  db.query(sql, [mat, nom, prenom, datenaiss, classe, filiere, universite, adresse, sexe, nationalite], err => {
    if (err) return res.status(500).send(err);
    res.redirect('/');
  });
});

app.get('/modifier/:id', (req, res) => {
  db.query('SELECT * FROM etudiants WHERE id = ?', [req.params.id], (err, result) => {
    if (err) return res.status(500).send(err);
    res.render('edit', { etudiant: result[0] });
  });
});

app.post('/modifier/:id', (req, res) => {
  const { mat, nom, prenom, datenaiss, classe, filiere, universite, adresse, sexe, nationalite } = req.body;
  const sql = 'UPDATE etudiants SET mat = ?, nom = ?, prenom = ?, datenaiss = ?, classe = ?, filiere = ?, universite = ?, adresse = ?, sexe = ?, nationalite = ? WHERE id = ?';
  db.query(sql, [mat, nom, prenom, datenaiss, classe, filiere, universite, adresse, sexe, nationalite, req.params.id], err => {
    if (err) return res.status(500).send(err);
    res.redirect('/');
  });
});

app.get('/supprimer/:id', (req, res) => {
  db.query('DELETE FROM etudiants WHERE id = ?', [req.params.id], err => {
    if (err) return res.status(500).send(err);
    res.redirect('/');
  });
});

// Un seul app.listen
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Serveur lancé sur http://localhost:${PORT}`);
});
