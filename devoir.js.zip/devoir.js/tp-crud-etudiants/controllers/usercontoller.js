const User = require('../models/usermodel'); 
 
exports.getAllUsers = async (req, res) => { 
  const [rows] = await User.getAll(); 
  res.json(rows); 
}; 
exports.getUserById = async (req, res) => { 
  const [rows] = await User.getById(req.params.id); 
  if (rows.length === 0) return res.status(404).json({ message: 'Utilisateur non trouvé' }); 
  res.json(rows[0]); 
}; 
 
exports.createUser = async (req, res) => { 
  const { name, email } = req.body; 
  await User.create({ name, email }); 
  res.status(201).json({ message: 'Utilisateur créé' }); 
}; 
 
exports.updateUser = async (req, res) => { 
  const { name, email } = req.body; 
  await User.update(req.params.id, { name, email }); 
  res.json({ message: 'Utilisateur mis à jour' }); 
}; 
 
exports.deleteUser = async (req, res) => {  await User.delete(req.params.id); 
  res.json({ message: 'Utilisateur supprimé' }); 
};