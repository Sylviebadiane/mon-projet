const db = require('../db'); 
const bcrypt = require('bcrypt'); 
 
class user {
     static async create(username, password) { 
    const hashedPassword = await bcrypt.hash(password, 10); 
    return db.promise().query('INSERT INTO users (username, password) VALUES (?, ?)', [username, hashed]); 
  } 
 
  static async findByUsername(username) { 
    const [rows] = await db.promise().query('SELECT * FROM users WHERE username = ?', [username]); 
    return rows[0]; 
  } 
 
  static async verifyPassword(inputPassword, storedPassword) { 
    return await bcrypt.compare(inputPassword, storedPassword); 
  } 
} 
  getAll: () => {
    return db.promise().query('SELECT * FROM users');
    }, 

  getById: (id) =>{
    return db.promise().query('SELECT * FROM users WHERE id = ?', [id]);
    }, 

  createAPI: (data) => {
    return db.promise().query(
      'INSERT INTO users (name, email) VALUES (?, ?)',
       [data.name, data.email]
      );
    }, 

  update: (id, data) =>{ db.promise().query(
    'UPDATE users SET name=?, email=? WHERE id=?',
     [data.name, data.email, id]
    );
     }, 

  delete: (id) => {db.promise().query('DELETE FROM users WHERE id = ?', [id]);
  }, 
  };
 
module.exports = user;