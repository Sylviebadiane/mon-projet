const express = require('express'); 
const router = express.Router(); 
const User = require('../models/User'); 
 
// Affiche le formulaire d'inscription 
router.get('/register', (req, res) => { 
  res.render('register'); 
}); 
 
// Traite l'inscription 
router.post('/register', async (req, res) => { 
  const { username, password } = req.body; 
  try { 
    await User.create({username, password}); 
    res.redirect('/login'); 
  } catch (err) { 
    res.send('Erreur lors de l\'inscription'); 
  } 
});
// Formulaire de login 
router.get('/login', (req, res) => { 
  res.render('login'); 
}); 
 
// Traitement login 
router.post('/login', async (req, res) => { 
  const { username, password } = req.body; 
  const user = await User.findByUsername(username); 
  if (user && await User.verifyPassword(password, user.password)) { 
    req.session.userId = user.id; 
    res.redirect('/dashboard'); 
  } else { 
    res.send('Identifiants invalides'); 
  } 
}); 
 
// Dashboard protégé 
router.get('/dashboard', (req, res) => { 
  if (!req.session.userId) return res.redirect('/login');
    res.render('dashboard'); 
}); 
 
// Déconnexion 
router.get('/logout', (req, res) => { 
  req.session.destroy(() => { 
    res.redirect('/login'); 
  }); 
}); 
 
module.exports = router;